package com.amdocs.finalproject.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.amdocs.finalproject.action.Action;
import com.amdocs.finalproject.base.Base;

public class SignInPage extends Base {
	
	@FindBy(xpath= "//*[@id=\"ap_email\"]")
	WebElement emailtextbox ;
	
	@FindBy(xpath="//*[@id=\"continue\"]")
	WebElement continuebtn;
	
	@FindBy(xpath = "//*[@id=\"ap_password\"]")
	WebElement passwordtextbox;
	
	@FindBy(xpath="//*[@id=\"signInSubmit\"]")
	WebElement signinbtn;
	
	public SignInPage() {
		PageFactory.initElements(driver, this);
	}
	
	public HomePage login() throws Exception
	{
		Action.type(emailtextbox,"7470921930");
		Action.click(driver, continuebtn);
		Action.type(passwordtextbox, "muskanag");
		Action.click(driver, signinbtn);
		return new HomePage();
	}
	

}
