package com.amdocs.finalproject.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.amdocs.finalproject.action.Action;
import com.amdocs.finalproject.base.Base;

public class IndexPage extends Base {
	
	
	
	public IndexPage()
	{
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath="//*[@id=\"nav-link-accountList\"]")
	WebElement signin ;
	public SignInPage SignInPage() throws Exception {
		Action.click(driver, signin);
		return new SignInPage();
	}
	

}
