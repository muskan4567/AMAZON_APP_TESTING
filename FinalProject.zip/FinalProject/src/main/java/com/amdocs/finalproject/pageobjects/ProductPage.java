package com.amdocs.finalproject.pageobjects;

import java.util.ArrayList;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.amdocs.finalproject.action.Action;
import com.amdocs.finalproject.base.Base;

public class ProductPage extends Base{
	
	public ProductPage()
	{
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//*[@id=\"buy-now-button\"]")
	WebElement buynowbtn;
	
	public BuyNowPage BuyNow() throws Exception
	{
	
		ArrayList<String> newTb = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(newTb.get(1));
		Action.Wait(driver, 5);
		Action.click(driver, buynowbtn);
		Thread.sleep(3000);
		return new BuyNowPage();
	}
}
