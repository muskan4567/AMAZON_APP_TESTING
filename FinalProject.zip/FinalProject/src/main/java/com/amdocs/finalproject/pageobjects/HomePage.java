package com.amdocs.finalproject.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.amdocs.finalproject.action.Action;
import com.amdocs.finalproject.base.Base;

public class HomePage extends Base{
	
	public HomePage()
	{
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//*[@id=\"twotabsearchtextbox\"]")
	WebElement searchtextbox;
	
	@FindBy(xpath = "//*[@id=\"nav-search-submit-button\"]")
	WebElement searchbtn;
	
	@FindBy(xpath = "//*[@id=\"search\"]/div[1]/div[1]/div/span[1]/div[1]/div[3]/div/div/div/div/div/div/div/div[2]/div/div/div[1]/h2/a/span")
	WebElement product;
	
	public ProductPage SearchPage() throws Exception {
		Action.click(driver, searchtextbox);
		Action.type(searchtextbox, "Mobile Phone");
		Action.click(driver, searchbtn);
		Action.click(driver, product);
		return new ProductPage();
	}

}
