package com.amdocs.finalproject.pageobjects;

import org.openqa.selenium.support.PageFactory;

import com.amdocs.finalproject.base.Base;

public class PlaceOrderPage extends Base{
	public PlaceOrderPage()
	{
		PageFactory.initElements(driver, this);
	}

}
