package com.amdocs.finalproject.pageobjects;

import java.util.ArrayList;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.amdocs.finalproject.action.Action;
import com.amdocs.finalproject.base.Base;

public class BuyNowPage extends Base {
	
	public BuyNowPage()
	{
		PageFactory.initElements(driver, this);
	}


	
	
	@FindBy(xpath="//*[@id=\"orderSummaryPrimaryActionBtn\"]/span/input")
	WebElement usethispaymentmethod;
	
	public PlaceOrderPage PaymentWindow() throws Exception {
		Action.click(driver, usethispaymentmethod);
		return new PlaceOrderPage();
	}

}
