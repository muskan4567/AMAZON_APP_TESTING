package com.amdocs.finalproject.testcases;

import java.io.IOException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.amdocs.finalproject.base.Base;
import com.amdocs.finalproject.pageobjects.BuyNowPage;
import com.amdocs.finalproject.pageobjects.HomePage;
import com.amdocs.finalproject.pageobjects.IndexPage;
import com.amdocs.finalproject.pageobjects.PlaceOrderPage;
import com.amdocs.finalproject.pageobjects.ProductPage;
import com.amdocs.finalproject.pageobjects.SignInPage;

public class IndexTestCase extends Base {
	
	private IndexPage ip;
	
	@BeforeMethod
	public void SetUp() throws IOException
	{
		loadConfig();
		launchApp();
		ip = new IndexPage();
	}
	@Test
	public void onClickTest() throws Exception
	{
		SignInPage sp = ip.SignInPage();
		HomePage hp = sp.login();
		ProductPage pp = hp.SearchPage();
		Thread.sleep(3000);
		BuyNowPage bp = pp.BuyNow();
		PlaceOrderPage pop = bp.PaymentWindow();
	}
	

}
